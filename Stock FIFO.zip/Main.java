/*
File: Main.java
Description: Simulates the FIFO system of the US stock market based on simulation.dat text file
Created: Mon. May 31, 2021
email: garyl4603@student.vvc.edu
*/

import java.io.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.text.ParseException;


public class Main
{
  File file = new File("simulation.dat");
  Scanner in = new Scanner(file);
  ReportWriter report = new ReportWriter();
  DateTimeFormatter form = DateTimeFormatter.ofPattern("MM/dd/yyyy");
  public Map<String, Queue<StockBlock>> blocks = new HashMap<String, Queue<StockBlock>>();
  // a map of queues of stockblocks
  boolean done = false;
  //Variables used for parsing each line
    String action;
    String stonk;
    int quantity;
    int price;
    LocalDate date;
  //-----------------------------------//

   

   public Main() throws FileNotFoundException
   {
      while (!done)
      {
         action = in.next(); // This scans file, with each line being split by variable
         if (in.hasNext()) // if statement avoids null when quitting
         {

            stonk = in.next();
            quantity = Integer.parseInt(in.next());
            price = Integer.parseInt(in.next());
            date = LocalDate.parse(in.next(), form);

         }

         if (action.equals("buy")) 
         {

            buy(stonk, quantity, price, date);

         }

         else if (action.equals("sell")) 
         {

            sell(stonk, quantity, price, date);

         }

         else if (action.equals("quit"))
         {

            report.report(); // print report on completion
            done = true;

         }
      }
   }


   //----------------------------------------------------------------//
   // filters through and creates a stockblock and or queue of stock //

   public void buy(String symbol, int quantity, int price,LocalDate buy_date) {
      Queue<StockBlock> stockQueue;
      if (!blocks.containsKey(symbol))
      {

         stockQueue = new LinkedList<StockBlock>();

      }

      else
      {

         stockQueue = blocks.get(symbol);

      }
      
      stockQueue.add(new StockBlock(quantity, price, buy_date));
      blocks.put(symbol, stockQueue);
   }


   //-------------------------------------------------------------//
   // Tests for presence of stock, then retrieves 
   // queue from "blocks" hashmap and sells

   public void sell(String symbol, int quantity, int price,LocalDate sell_date) {

      if (!blocks.containsKey(symbol)) 
      {

         System.out.println("There are no stocks for " + symbol + " to sell.");
         return;

      }

      Queue<StockBlock> stockQueue = blocks.get(symbol);

      if (stockQueue.size() < 1)
      {

         System.out.println("There are no stocks for " + symbol + " to sell.");
         return;

      }

      /*
      Calculates gain from StockBlock.sell and finds remaining stocks to be sold from sell function if any remaining.
      Adds gain and info to data structure in ReportWriter class
      */

      double gain = stockQueue.peek().sell(quantity, price, sell_date);
      int left = stockQueue.peek().getLeft();
      report.addrepo(quantity - left, symbol, price, sell_date, gain);

      if (stockQueue.peek().isEmpty()) // Removes Empty StockBlock
      {

        stockQueue.remove();

      }

      if (left > 0) //checks for left over quantity from "sell" action and ports for recursion
      {

        sell(symbol, left, price, sell_date);
        
      }
   }



   public static void main(String[] args) throws ParseException
   {
      try {
        Main simulator = new Main();
      }
      catch(FileNotFoundException e) {
          System.out.println(e);
      }
   }
}