import java.time.LocalDate;

/**
   Class for a maintaining a quantity and price of a block of stocks.
*/
public class StockBlock
{
   private final int price;
   private int quantity;
   private LocalDate buy_date;
   private LocalDate sell_date;
   private int leftover = 0;
  
  
   //---------------------Constructor--------------------//

   public StockBlock(int quantity, int price,LocalDate buy_date)
   {
      this.quantity = quantity;
      this.price = price;
      this.buy_date = buy_date;
   }



  //-------------------------Sell------------------------//

   public double sell(int quantity, int price,LocalDate sell_date)
   {
      this.sell_date = sell_date;
      if (this.quantity < quantity) {

         double gain = (this.quantity*(price-this.price));
         leftover = quantity - this.quantity; 
            // calculates amount not sold if selling more than this stock block. Does not reset because stockblock gets removed when empty anyway
         this.quantity = 0;
         return gain;

      }

      else {

         double gain = (quantity*(price-this.price));
         this.quantity = this.quantity - quantity;
         return gain;

      }
   }
   


   public int getLeft() {

      return leftover;

   }

   public boolean isEmpty() {

      return (quantity == 0);

   }
}