import java.util.*;
import java.time.LocalDate;

/**
class for reporting data holistically
*/
public class ReportWriter {

  ArrayList<String[]> fullRep = new ArrayList<String []>();
  double tot;
  
//-------------------------------------------------------//
// adds to sales report via arraylist of arrays //

  public void addrepo (int quantity, String symbol, int price, LocalDate sell_date, Double gain) {
    String[] report = {String.valueOf(quantity), symbol, String.valueOf(price), String.valueOf(sell_date), String.valueOf(gain)};
    fullRep.add(report);
  }

//-------------------------------------------------------//
// returns report extracting and converting as necessary //

  public void report () {
    for (String[] sale: fullRep) 
    {

      System.out.println("\n" + sale[0] + " of " + sale[1] + " sold.\nSell Date: " + sale[3] + "\nPrice per unit: " + sale[2] + "\nGain: $" + sale[4]);
      tot = tot + Double.parseDouble(sale[4]); // computes running total
    
    }
    
    System.out.println("\nTotal Gains: $" + tot);

    System.out.println("System.thank: Thank you professor, you were fantastic!");
  }
}